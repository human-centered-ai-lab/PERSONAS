# About this document

This zip-file contains a **latex template for personas visualisation**, 
specifically designed to support design and development of human-centered AI. 

This template was created using the open source tool overleaf (https://www.overleaf.com).
To use this template, you can __import this zip-file as a project to overleaf__.




LICENCE:
---------
This persona template is made available under Creative Commons BY-NC 4.0 license 
by Human-Centered AI Lab / Research and Diagnostics Institute of Pathology at Medical University Graz.  
Please _cite_ **Holzinger et al "Personas for AI: An Open-Source Toolbox" (2021)** on use.